package studentDetails.demo.repository;
import studentDetails.demo.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface Repo extends MongoRepository<Student, String> {

}
