package studentDetails.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import studentDetails.demo.model.Student;
import studentDetails.demo.repository.Repo;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/students")
public class StudentControl {
    @Autowired
    private Repo studentRepository;


    @GetMapping(path = "/")
    public List<Student> getStudentDetails(){
        List<Student> students = studentRepository.findAll();
        return students;
    }

    @GetMapping(path = "/{id}")
    public Optional<Student> getStudentDetails(@PathVariable("id") String id){
        Optional<Student> student = studentRepository.findById(id);
        return student;
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<Student> deleteStudent(@PathVariable("id") String id) {
        studentRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping(path = {"/add"})
    public Student createStudent(@RequestBody Student student) {
        Student createdStudent = this.studentRepository.save(student);
        return student;
    }


//    @PutMapping("/student/{id}")
//    public String updateStudent(@PathVariable("id") String id, @RequestBody Student student) {
//            s = studentRepository.findById(id);
////          String branch = student.getBranch();
////          s
//
//
//    }

//

}

